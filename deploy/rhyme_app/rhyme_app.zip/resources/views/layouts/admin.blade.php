<!DOCTYPE html>
<html lang="zxx" class="js">

<head>
    <base href="{{ url('/') }}/">
    <meta charset="utf-8">
    <meta name="author" content="Softnio">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="A powerful and conceptual apps base dashboard template that especially build for developers and programmers.">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- Fav Icon  -->
    <link rel="shortcut icon" href="./images/favicon.png">
    <!-- Page Title  -->
    <title>@yield('title', 'Admin Panel | Rhymes Platform')</title>
    <!-- StyleSheets  -->
    <link rel="stylesheet" href="{{ asset('assets/css/dashlite.css?ver=3.2.3') }}">
    <link id="skin-default" rel="stylesheet" href="{{ asset('assets/css/theme.css?ver=3.2.3') }}">
    <link rel="stylesheet" href="{{ asset('css/theme-overrides.css') }}">
    <link rel="stylesheet" href="{{ asset('css/custom.css') }}">
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        /* SweetAlert2 Custom Styles */
        .swal2-popup {
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
        }
        
        .swal2-title {
            font-size: 1.25rem;
            font-weight: 600;
        }
        
        .swal2-content {
            font-size: 1rem;
        }
        
        .swal2-success {
            border-color: #20d08c;
        }
        
        .swal2-error {
            border-color: #e85347;
        }
        
        .swal2-warning {
            border-color: #f4bd0e;
        }
        
        .swal2-info {
            border-color: #099fff;
        }
    </style>
</head>

<body class="nk-body bg-lighter npc-general has-sidebar ">
    <div class="nk-app-root">
        <!-- main @s -->
        <div class="nk-main ">
            <!-- sidebar @s -->
            <div class="nk-sidebar nk-sidebar-fixed is-light " data-content="sidebarMenu">
                <div class="nk-sidebar-element nk-sidebar-head">
                    <div class="nk-sidebar-brand">
                       
                            
                            <img class=""  height="100px"  src="{{asset('/images/rovingHeights-logo.png')}}" srcset="{{ asset('images/rovingHeights-logo.png 2x') }}" alt="logo-dark">
                           
               
                    </div>
                    {{-- <div class="nk-menu-trigger me-n2">
                        <a href="#" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu"><em class="icon ni ni-arrow-left"></em></a>
                        <a href="#" class="nk-nav-compact nk-quick-nav-icon d-none d-xl-inline-flex" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                    </div> --}}
                </div><!-- .nk-sidebar-element -->
                <div class="nk-sidebar-element">
                    <div class="nk-sidebar-content">
                        <div class="nk-sidebar-menu" data-simplebar>
                            <ul class="nk-menu">
                                <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">Admin Panel</h6>
                                </li><!-- .nk-menu-item -->
                                <li class="nk-menu-item has-sub">
                                    <a href="{{ route('admin.dashboard') }}" class="nk-menu-link " style="color: #364a63">
                                        <span class="nk-menu-icon"><em class="icon ni ni-dashboard-fill"></em></span>
                                        <span class="nk-menu-text">Dashboards</span>
                                    </a>
                                    {{-- <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.dashboard') }}" class="nk-menu-link"><span class="nk-menu-text">Main Dashboard</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.reports.sales') }}" class="nk-menu-link"><span class="nk-menu-text">Sales Reports</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.reports.analytics') }}" class="nk-menu-link"><span class="nk-menu-text">Analytics</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.unified-dashboard') }}" class="nk-menu-link"><span class="nk-menu-text">Unified Dashboard</span></a>
                                        </li>
                                    </ul> --}}
                                </li><!-- .nk-menu-item -->
                                
                                <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">Management</h6>
                                </li><!-- .nk-menu-heading -->
                                
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-users-fill"></em></span>
                                        <span class="nk-menu-text">Users</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.users.index') }}" class="nk-menu-link"><span class="nk-menu-text">All Users</span></a>
                                        </li>
                                       
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.users.trashed') }}" class="nk-menu-link"><span class="nk-menu-text">Trashed Users</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.users.activity') }}" class="nk-menu-link"><span class="nk-menu-text">User Activity</span></a>
                                        </li>
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-book-fill"></em></span>
                                        <span class="nk-menu-text">Books</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.books.index') }}" class="nk-menu-link"><span class="nk-menu-text">All Books</span></a>
                                        </li>
                                        <!-- <li class="nk-menu-item">
                                            <a href="{{ route('admin.books.logs') }}" class="nk-menu-link"><span class="nk-menu-text">Review Logs</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.books.pending') }}" class="nk-menu-link"><span class="nk-menu-text">Pending Review</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.books.published') }}" class="nk-menu-link"><span class="nk-menu-text">Published</span></a>
                                        </li> -->
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-money"></em></span>
                                        <span class="nk-menu-text">Revenue</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.revenue.index') }}" class="nk-menu-link"><span class="nk-menu-text">Revenue</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.payouts.index') }}" class="nk-menu-link"><span class="nk-menu-text">Payouts</span></a>
                                        </li>
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                
                                <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">ERPREV Integration</h6>
                                </li><!-- .nk-menu-heading -->
                                
                                <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-swap"></em></span>
                                        <span class="nk-menu-text">ERPREV Data</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.erprev.sales') }}" class="nk-menu-link"><span class="nk-menu-text">Sales Data</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.erprev.inventory') }}" class="nk-menu-link"><span class="nk-menu-text">Inventory</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.erprev.products') }}" class="nk-menu-link"><span class="nk-menu-text">Products</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.erprev.test-endpoints') }}" class="nk-menu-link"><span class="nk-menu-text">Test Endpoints</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="{{ route('admin.erprev.monitoring') }}" class="nk-menu-link"><span class="nk-menu-text">Sync Monitoring</span></a>
                                        </li>
                                    </ul><!-- .nk-menu-sub -->
                                </li><!-- .nk-menu-item -->
                                
                                {{-- <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">ERPREV Integration</h6>
                                </li> --}}
                                
                                {{-- <li class="nk-menu-item">
                                    <a href="{{ route('admin.reports.sales-dashboard') }}" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-dashboard"></em></span>
                                        <span class="nk-menu-text">Sales Dashboard</span>
                                    </a>
                                </li>
                                
                                <li class="nk-menu-item">
                                    <a href="{{ route('admin.reports.sales') }}" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-growth-fill"></em></span>
                                        <span class="nk-menu-text">Sales Reports</span>
                                    </a>
                                </li>
                                
                                <li class="nk-menu-item">
                                    <a href="{{ route('admin.reports.analytics') }}" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-bar-chart-fill"></em></span>
                                        <span class="nk-menu-text">Analytics</span>
                                    </a>
                                </li> --}}
                                
                                {{-- <li class="nk-menu-item">
                                    <a href="{{ route('admin.users.activity') }}" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-activity-alt"></em></span>
                                        <span class="nk-menu-text">User Activities</span>
                                    </a>
                                </li> --}}
                                
                                <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">System</h6>
                                </li>
                                
                                {{-- <li class="nk-menu-item">
                                    <a href="{{ route('admin.emails.index') }}" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-mail-fill"></em></span>
                                        <span class="nk-menu-text">Email Management</span>
                                    </a>
                                </li>
                                 --}}
                                <li class="nk-menu-item">
                                    <a href="{{ route('admin.settings') }}" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-setting-fill"></em></span>
                                        <span class="nk-menu-text">Settings</span>
                                    </a>
                                </li>
                                
                                {{-- <li class="nk-menu-item">
                                    <a href="{{ route('admin.notifications.index') }}" class="nk-menu-link">
                                        <span class="nk-menu-icon"><em class="icon ni ni-bell-fill"></em></span>
                                        <span class="nk-menu-text">Notifications</span>
                                    </a>
                                </li> --}}
                            </ul><!-- .nk-menu -->
                        </div><!-- .nk-sidebar-menu -->
                    </div><!-- .nk-sidebar-content -->
                </div><!-- .nk-sidebar-element -->
            </div><!-- sidebar @e -->
            
            <!-- wrap @s -->
            <div class="nk-wrap ">
                <!-- main header @s -->
                <div class="nk-header nk-header-fixed is-light">
                    <div class="container-fluid">
                        <div class="nk-header-wrap">
                            <div class="nk-menu-trigger d-xl-none ms-n1">
                                <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                            </div>
                            <div class="nk-header-brand d-xl-none">
                               
                                    <img class="logo-light logo-img" width="100px" src="{{asset('/images/rovingHeights-logo.png')}}" srcset="{{asset('/images/rovingHeights-logo.png')}} 2x" alt="logo">
                                 
                               
                            </div><!-- .nk-header-brand -->
                            <div class="nk-header-news d-none d-xl-block">
                                {{-- <div class="nk-news-list">
                                    <a class="nk-news-item" href="#">
                                        <div class="nk-news-icon">
                                            <em class="icon ni ni-card-view"></em>
                                        </div>
                                        <div class="nk-news-text">
                                            <p>@yield('page-title', 'Admin Panel') <span> @yield('page-description', 'Manage your platform')</span></p>
                                            <em class="icon ni ni-external"></em>
                                        </div>
                                    </a>
                                </div> --}}
                            </div><!-- .nk-header-news -->
                            <div class="nk-header-tools">
                                <ul class="nk-quick-nav">
                                    <!-- Dark Mode Toggle -->
                                    <li class="dropdown">
                                        <a href="#" id="darkModeToggle" class="nk-quick-nav-icon">
                                            <div class="quick-icon">
                                                <em id="darkModeIcon" class="icon ni ni-moon"></em>
                                            </div>
                                        </a>
                                    </li>
                                   
                                    @php
                                        $unreadCount = auth()->check() ? auth()->user()->unreadNotifications()->count() : 0;
                                    @endphp
                                    <li class="dropdown notification-dropdown">
                                        <a href="#" class="dropdown-toggle nk-quick-nav-icon" data-bs-toggle="dropdown">
                                            <div style="position: relative; display: inline-block;">
                                                <em class="icon ni ni-bell"></em>
                                                <span class="notification-badge" style="{{ $unreadCount > 0 ? 'display: flex;' : 'display: none;' }} position: absolute; top: -6px; right: -6px; background: #e85347; color: white; border-radius: 50%; width: 18px; height: 18px; font-size: 10px; align-items: center; justify-content: center;">{{ $unreadCount > 99 ? '99+' : $unreadCount }}</span>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-xl dropdown-menu-end">
                                            <div class="dropdown-head">
                                                <span class="sub-title nk-dropdown-title">
                                                    Admin Notifications
                                                    <span class="badge bg-primary rounded-pill header-notification-count ms-1" style="{{ $unreadCount > 0 ? '' : 'display: none;' }}">{{ $unreadCount > 99 ? '99+' : $unreadCount }}</span>
                                                </span>
                                                <a href="#" id="markAllAsRead">Mark All as Read</a>
                                            </div>
                                            <div class="dropdown-body">
                                                <div class="nk-notification" id="notificationsList">
                                                    <div class="nk-notification-item text-center py-4">
                                                        <div class="nk-notification-content">
                                                            <div class="nk-notification-text text-muted">Loading notifications...</div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="dropdown-foot center">
                                                <a href="#">View All</a>
                                            </div>
                                        </div>
                                    </li>

                                    <li class="dropdown user-dropdown">
                                        <a href="#" class="dropdown-toggle me-n1" data-bs-toggle="dropdown">
                                            <div class="user-toggle">
                                                <div class="user-avatar sm">
                                                    <em class="icon ni ni-user-alt"></em>
                                                </div>
                                                <div class="user-info d-none d-xl-block">
                                                    <div class="user-status user-status-admin">Administrator</div>
                                                    <div class="user-name dropdown-indicator">{{ auth()->user()->name }}</div>
                                                </div>
                                            </div>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-md dropdown-menu-end">
                                            <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                                <div class="user-card">
                                                    <div class="user-avatar">
                                                        @if(auth()->user()->avatar)
                                                            <img src="{{ asset('storage/images/avatar/' . auth()->user()->avatar) }}" alt="{{ auth()->user()->name }}">
                                                        @else
                                                            <img src="{{ asset('storage/images/avatar/default.png') }}" alt="{{ auth()->user()->name }}">
                                                        @endif
                                                    </div>
                                                    <div class="user-info">
                                                        <span class="lead-text">{{ auth()->user()->name }}</span>
                                                        <span class="sub-text">{{ auth()->user()->email }}</span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="dropdown-inner">
                                                <ul class="link-list">
                                                    <li><a href="{{ route('admin.profile.index') }}"><em class="icon ni ni-user-alt"></em><span>View Profile</span></a></li>
                                                    {{-- <li><a href="{{ route('admin.settings') }}"><em class="icon ni ni-setting-alt"></em><span>Account Settings</span></a></li> --}}
                                                    <li><a href="#" id="loginActivityLink"><em class="icon ni ni-activity-alt"></em><span>Login Activity</span></a></li>
                                                    <li><a href="#" id="darkModeToggleProfile"><em class="icon ni ni-moon"></em><span>Dark Mode</span></a></li>
                                                    @if(auth()->user()->hasRole('author'))
                                                        <li><a href="/author/dashboard"><em class="icon ni ni-swap-alt"></em><span>Switch to Author</span></a></li>
                                                    @endif
                                                </ul>
                                            </div>
                                            <div class="dropdown-inner">
                                                <ul class="link-list">
                                                    <li>
                                                        <form method="POST" action="{{ route('logout') }}">
                                                            @csrf
                                                            <a href="#" onclick="event.preventDefault(); this.closest('form').submit();">
                                                                <em class="icon ni ni-signout"></em><span>Sign out</span>
                                                            </a>
                                                        </form>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div><!-- .nk-header-wrap -->
                    </div><!-- .container-fliud -->
                </div>
                <!-- main header @e -->
                
                @yield('content')
                
                <!-- footer @s -->
                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                            <div class="nk-footer-copyright">    <p class="text-soft">&copy; <?php echo date("Y"); ?> Roving Heights. All Rights Reserved.</p>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    
    <!-- Pusher JS library -->
    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    
    <script>
        // Pusher configuration from Laravel
        window.pusherKey = '{{ config("broadcasting.connections.pusher.key") }}';
        window.pusherCluster = '{{ config("broadcasting.connections.pusher.options.cluster") }}';
        window.userId = {{ auth()->check() ? auth()->user()->id : 'null' }};
    </script>
    
    <!-- JavaScript -->
    <script src="{{ asset('assets/js/bundle.js?ver=3.2.3') }}"></script>
    <script src="{{ asset('assets/js/scripts.js?ver=3.2.3') }}"></script>
    <script src="{{ asset('assets/js/charts/chart-ecommerce.js?ver=3.2.3') }}"></script>
    <!-- Notifications Script -->
    <script src="{{ asset('js/notifications.js?ver=1.1') }}"></script>
    <script src="{{ asset('js/admin.js') }}"></script>
    <script src="{{asset('/assets/js/libs/datatable-btns.js')}}"></script>

    
    <!-- SweetAlert2 Initialization -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Display success message if session has 'success' key
            @if(session('success'))
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: '{{ session('success') }}',
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end'
                });
            @endif

            // Display error message if session has 'error' key
            @if(session('error'))
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: '{{ session('error') }}',
                    showConfirmButton: true,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#e85347'
                });
            @endif

            // Display warning message if session has 'warning' key
            @if(session('warning'))
                Swal.fire({
                    icon: 'warning',
                    title: 'Warning!',
                    text: '{{ session('warning') }}',
                    showConfirmButton: true,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#f4bd0e'
                });
            @endif

            // Display info message if session has 'info' key
            @if(session('info'))
                Swal.fire({
                    icon: 'info',
                    title: 'Info',
                    text: '{{ session('info') }}',
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end'
                });
            @endif
            
            // Global function to show SweetAlert messages
            window.showSuccessMessage = function(message) {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: message,
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end'
                });
            };
            
            window.showErrorMessage = function(message) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: message,
                    showConfirmButton: true,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#e85347'
                });
            };
            
            window.showWarningMessage = function(message) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Warning!',
                    text: message,
                    showConfirmButton: true,
                    confirmButtonText: 'OK',
                    confirmButtonColor: '#f4bd0e'
                });
            };
            
            window.showInfoMessage = function(message) {
                Swal.fire({
                    icon: 'info',
                    title: 'Info',
                    text: message,
                    timer: 3000,
                    timerProgressBar: true,
                    showConfirmButton: false,
                    toast: true,
                    position: 'top-end'
                });
            };
            
            // Confirm dialog function
            window.confirmAction = function(message, callback) {
                Swal.fire({
                    title: 'Are you sure?',
                    text: message,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#e85347',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, proceed!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        callback();
                    }
                });
            };
        });
    </script>
    
    @yield('scripts')
    @stack('scripts')
</body>

</html>