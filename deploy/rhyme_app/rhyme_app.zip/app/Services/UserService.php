<?php

namespace App\Services;

use App\Models\User;
use App\Notifications\NewUserCreated;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;

class UserService
{
    /**
     * Update user information
     *
     * @param User $user
     * @param array $data
     * @return User
     */
   public function updateUser(User $user, array $data)
{
    $updateData = [
        'name' => $data['name'],
        'email' => $data['email'],
        'phone' => $data['phone'] ?? null,
        'address' => $data['address'] ?? null,
        'account_description' => $data['account_description'] ?? null,
        
        'email_verified_at' => array_key_exists('email_verified', $data)
            ? ($data['email_verified'] ? now() : null)
            : $user->email_verified_at,

        'is_active' => array_key_exists('account_active', $data)
            ? (bool)$data['account_active']
            : false,
    ];

    $user->update($updateData);

    if (array_key_exists('roles', $data)) {
        $user->syncRoles($data['roles'] ?? []);
    }

    return $user;
}


    /**
     * Create a new user
     *
     * @param array $data
     * @return User
     */
    public function createUser(array $data)
    {
        // Auto-generate password if not provided in data
        $password = $data['password'] ?? Str::random(12);
        
        $userData = [
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($password),
            'phone' => $data['phone'] ?? null,
            'bio' => $data['bio'] ?? null,
            'website' => $data['website'] ?? null,
            'email_verified_at' => now(), // Admin created users are auto-verified
        ];

        $user = User::create($userData);
        $user->assignRole($data['role']);

        // Send notification with login details to the user
        $user->notify(new NewUserCreated($password));

        return $user;
    }

    /**
     * Reset user password
     *
     * @param User $user
     * @param string $password
     * @return User
     */
    public function resetPassword(User $user, string $password)
    {
        $user->update([
            'password' => Hash::make($password),
        ]);

        return $user;
    }

    /**
     * Promote user to author
     *
     * @param User $user
     * @return User
     */
    public function promoteToAuthor(User $user)
    {
        if (!$user->hasRole('author')) {
            $user->assignRole('author');
            $user->update(['promoted_to_author_at' => now()]);
        }

        return $user;
    }

    /**
     * Get all roles
     *
     * @return \Illuminate\Database\Eloquent\Collection
     */
    public function getAllRoles()
    {
        return Role::all();
    }
}